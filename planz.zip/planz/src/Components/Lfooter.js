import React from 'react'

const last =() =>{


    return (

<div className="lf"> 

<h className="lfh1">Copyright © 2020 Saylani Welfare</h>
</div>
    )
}
export default last