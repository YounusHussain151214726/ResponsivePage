import React from 'react'

const textslide =()=>{
    return (

        <div>
        <div className="lts">
<marquee direction="left" scrollamount="5" >(News-1 Dated:15-05-2019)  Saylani Welfare Announced "Donation Application" .More Details (News-2 Dated:07-05-2019)   Alhamdulillah Saylani Organized 200+ Locations For Iftar And Sehri In This Holy Month . More Details </marquee>

        </div>
    </div>
    )
}

export default textslide