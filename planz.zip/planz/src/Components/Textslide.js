import React from 'react'


const text=()=> {

return (


<div>

<div className="divslide">
    
     News-1 Dated:15-05-2019)  Saylani Welfare Announced "Donation Application" More Detail. 
</div>

</div>



)


}

export default text